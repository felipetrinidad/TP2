/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

import java.io.Serializable;

/**
 *
 * @author felip
public class Persona
 */
public class Persona implements Serializable{
    // Atributos
    private String nombre;
    private String domicilio;
    private String dni;
    private String telefono;
    private static final long serialVersionUID = 1L; 
    
    //Constructor
    public Persona(String nombre, String domicilio, String dni, String telefono){
        setNombre(nombre);
        setDomicilio(domicilio);
        setDNI(dni);
        setTelefono(telefono);
    }
    
    
    //Setters con validaciones
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio");
        }
        if (nombre.length() < 2 || nombre.length() > 50) {
            throw new IllegalArgumentException("El nombre debe tener entre 2 y 50 caracteres");
        }
        if (!nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras y espacios");
        }
        this.nombre = nombre.trim();
    }
    
    
    public void setDomicilio(String domicilio) {
        if (domicilio == null || domicilio.trim().isEmpty()) {
            throw new IllegalArgumentException("El domicilio es obligatorio");
        }
        if (domicilio.length() < 5 || domicilio.length() > 100) {
            throw new IllegalArgumentException("El domicilio debe tener entre 5 y 100 caracteres");
        }
        this.domicilio = domicilio.trim();
    }
    
    
    public void setDNI(String dni) {
        if (dni == null || dni.trim().isEmpty()) {
            throw new IllegalArgumentException("El DNI es obligatorio");
        }
        
        // Validar formato: 12.345.678
        if (!dni.matches("^\\d{2}\\.\\d{3}\\.\\d{3}$")) {
            throw new IllegalArgumentException(
                "Formato de DNI incorrecto.\nEjemplo: 12.345.678");
        }
        // Validar que las partes sean numéricas
        String[] partes = dni.split("\\.");
        for (String parte : partes) {
            if (!parte.matches("\\d+")) {
                throw new IllegalArgumentException("El DNI solo puede contener números y puntos");
            }
        }
        
        this.dni = dni.trim();
    }
    
    public void setTelefono(String telefono) {
        if (telefono == null || telefono.trim().isEmpty()) {
            throw new IllegalArgumentException("El teléfono es obligatorio");
        }
        
        // Limpiar el teléfono: quitar espacios, guiones, paréntesis
        String telefonoLimpio = telefono.replaceAll("[\\s\\-\\(\\)]", "");
        
        if (!telefonoLimpio.matches("\\d{6,15}")) {
            throw new IllegalArgumentException(
                "Formato de teléfono incorrecto. Debe tener 10 dígitos.\n" +
                "Ejemplo: 3754-123456"
            );
        }
        
        this.telefono = telefono.trim();
    }
    
    //Getters
    public String getNombre() {return nombre;}
    public String getDomicilio() { return domicilio; }
    public String getDNI() { return dni; }
    public String getTelefono() {return telefono;}
    
    @Override
    public String toString() {
        return nombre + ", DNI: " + dni + ", Telefono: " + telefono;
    }
}
