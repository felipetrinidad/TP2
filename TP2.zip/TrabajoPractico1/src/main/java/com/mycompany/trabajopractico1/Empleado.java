/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

import java.io.Serializable;

/**
 *
 * @author felip
 */
public class Empleado extends Persona implements Serializable{
    private static final long serialVersionUID = 1L;
    //Atributos
    private double salario;
    private Puesto puesto; // administrativo, técnico, gerente
    private String fechaIngreso;
    private Departamento departamento;
    
    // enum: "lista" de elementos predeterminados
    public enum Puesto {
        ADMINISTRATIVO,
        TECNICO,
        GERENTE
    }
    
    //Constructor
    public Empleado(String nombre, String domicilio, String dni, String telefono, double salario,
                    Puesto puesto, String fechaIngreso, Departamento departamento) {
        
        super(nombre, domicilio, dni, telefono);
        setSalario(salario);
        setPuesto(puesto);
        setFechaIngr(fechaIngreso);
        setDepartamento(departamento);
    }
    
    //Setters con validaciones
    public void setSalario(double salario) {
        if (salario <= 0) {
            throw new IllegalArgumentException("El salario debe ser mayor a 0");
        }
        this.salario = salario;
    }
    
    public void setPuesto(Puesto puesto) {
        if (puesto == null) {
            throw new IllegalArgumentException("El puesto es obligatorio");
        }
        this.puesto = puesto;
    }
    
    public void setFechaIngr(String fechaIngreso) {
        if (fechaIngreso == null || fechaIngreso.trim().isEmpty()) {
            throw new IllegalArgumentException("La fecha de ingreso es obligatoria");
        }
        // Validación básica de formato de fecha (puedes mejorarla)
        if (!fechaIngreso.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
            throw new IllegalArgumentException("Formato de fecha incorrecto. Use dd/mm/aaaa");
        }
        this.fechaIngreso = fechaIngreso;
    }
    
    public void setDepartamento(Departamento departamento) {
        if (departamento == null) {
            throw new IllegalArgumentException("El departamento es obligatorio");
        }
        this.departamento = departamento;
    }
    
    
    //Getters
    public double getSalario(){return salario;}
    public Puesto getPuesto(){return puesto;}
    public String getFechaIngr(){return fechaIngreso;}
    public Departamento getDepartamento() { return departamento; }
    
    
    @Override
    public String toString() {
        return super.toString() + " Puesto: " + getPuesto()  + ", Fecha Ingreso: " + getFechaIngr();
    }
}
