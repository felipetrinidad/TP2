/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

/**
 *
 * @author felip
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class Proveedor extends Persona implements Serializable{
    private String razonSocial;
    private String nif; // Número Identificación Fiscal
    private List<ProductoServicio> productosServicios;
    private static final long serialVersionUID = 1L;
    
    public Proveedor(String nom, String dom, String dni, String tel, String razonSocial, String nif){
        super(nom, dom, dni, tel);
        this.productosServicios = new ArrayList<>();
        setRazSocial(razonSocial);
        setNIF(nif);
    }
    
    
    // Setters con Validacion
    public void setRazSocial(String razonSocial) {
        if (razonSocial == null || razonSocial.trim().isEmpty()) {
            throw new IllegalArgumentException("La razón social es obligatoria");
        }
        this.razonSocial = razonSocial.trim();
    }
    
    public void setNIF(String nif) {
        if (nif == null || nif.trim().isEmpty()) {
            throw new IllegalArgumentException("El NIF es obligatorio");
        }
        if (!nif.matches("[0-9]{11}")) {
            throw new IllegalArgumentException("Formato de NIF inválido. Ej: 12345678901");
        }
        this.nif = nif;
    }

    //Getters
    public String getRazSocial() { return razonSocial; }
    public String getNIF() { return nif; }
    
    
    
    //CRUD Productos - Servicios del Proveedor
    public void agregarProductoServicio(ProductoServicio productoServicio) {
        if (productoServicio == null) {
            throw new IllegalArgumentException("El producto/servicio no puede ser nulo");
        }
        if (buscarProductoServicio(productoServicio.getCodigo()) != null) {
            throw new IllegalArgumentException("Ya existe un producto/servicio con el código: " + productoServicio.getCodigo());
        }
        productosServicios.add(productoServicio);
    }
    
    public boolean eliminarProductoServicio(String codigo) {
        ProductoServicio productoServicio = buscarProductoServicio(codigo);
        if (productoServicio != null) {
            productosServicios.remove(productoServicio);
            return true;
        }
        return false;
    }
    
    public ProductoServicio buscarProductoServicio(String codigo) {
        for (ProductoServicio ps : productosServicios) {
                if (ps.getCodigo().equals(codigo)) {
                return ps;
                }
            }
            return null;
        }
    
    public boolean actualizarProductoServicio(ProductoServicio productoServicioActualizado) {
        for (int i = 0; i < productosServicios.size(); i++) {
            if (productosServicios.get(i).getCodigo().equalsIgnoreCase(productoServicioActualizado.getCodigo())) {
                productosServicios.set(i, productoServicioActualizado);
                return true;
            }
        }
        return false;
    }
    
    public List<ProductoServicio> getProductosServicios() {
        return new ArrayList<>(productosServicios);
    }
    
    
    public int getCantidadProductosServicios() {
        return productosServicios.size();
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Razón Social: " + razonSocial + ", NIF: " + nif + 
               ", Productos/Servicios: " + getCantidadProductosServicios() + " registrados";
    }
}
