/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

/**
 *
 * @author felip
 */
import java.io.*;

import java.util.ArrayList;
import java.util.List;

public class GestorClientes {
    private List<Cliente> clientes;
    private final String ARCHIVO_CLIENTES = "clientes.dat";

    public GestorClientes() {
        this.clientes = new ArrayList<>();
        cargarClientes(); // metodo para cargar clientes al iniciar
    }
    
    // Metodos para guardar los clientes en un archivo
    private void guardarClientes() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_CLIENTES))) {
            oos.writeObject(clientes);
            System.out.println("Clientes guardados en: " + ARCHIVO_CLIENTES);
        } catch (IOException e) {
            System.err.println("Error al guardar clientes: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void cargarClientes() {
        File archivo = new File(ARCHIVO_CLIENTES);
        if (!archivo.exists()) {
            System.out.println("No existe archivo de clientes, se creará uno nuevo");
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_CLIENTES))) {
            clientes = (List<Cliente>) ois.readObject();
            System.out.println("Clientes cargados: " + clientes.size() + " registros");
        }catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar clientes: " + e.getMessage());
            // Si hay error se empieza con lista vacía
            clientes = new ArrayList<>();
        }
    }
    
    
    // Create: agregar un nuevo cliente
    public boolean agregarCliente(Cliente cliente) {
        if (existeCliente(cliente.getDNI())) {
            return false;
        }
        clientes.add(cliente);
        guardarClientes(); // Guardar despues de agregar
        return true;
    }

    // Read: obtener todos los clientes
    public List<Cliente> getClientes() {
        return new ArrayList<>(clientes); 
    }

    // Read: buscar cliente por DNI
        public Cliente buscarCliente(String dni) {
            for (Cliente cliente : clientes) {
                if (cliente.getDNI().equals(dni)) {
                return cliente;
                }
            }
            return null;
        }

    // Update: actualizar un cliente existente
     public boolean actualizarCliente(Cliente clienteActualizado) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getDNI().equals(clienteActualizado.getDNI())) {
                clientes.set(i, clienteActualizado);
                guardarClientes(); // Guardar despues de actualizar
                return true;
            }
        }
        return false;
    }

    // Delete: eliminar un cliente por DNI
    public boolean eliminarCliente(String dni) {
        Cliente cliente = buscarCliente(dni);
        if (cliente != null) {
            clientes.remove(cliente);
            guardarClientes(); //  Guardar dspues de eliminar
            return true;
        }
        return false;
    }
    
    // Método para verificar existencia
    private boolean existeCliente(String dni) {
        return buscarCliente(dni) != null;
    }
}