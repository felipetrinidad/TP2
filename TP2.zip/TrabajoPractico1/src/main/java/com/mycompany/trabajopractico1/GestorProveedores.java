/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

/**
 *
 * @author felip
 */
import java.util.ArrayList;
import java.util.List;
import java.io.*;


public class GestorProveedores {
    private List<Proveedor> proveedores;
    private final String ARCHIVO_PROVEEDORES = "proveedores.dat";
    
    public GestorProveedores() {
        this.proveedores = new ArrayList<>();
        cargarProveedores();
    }

    
    // Metodos para guardar proveedor en un archivo
    private void guardarProveedores() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_PROVEEDORES))) {
            oos.writeObject(proveedores);
            System.out.println("Proveedores guardados en: " + ARCHIVO_PROVEEDORES);
        } catch (IOException e) {
            System.err.println("Error al guardar proveedores: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void cargarProveedores() {
        File archivo = new File(ARCHIVO_PROVEEDORES);
        if (!archivo.exists()) {
            System.out.println("No existe archivo de proveedores, se creará uno nuevo");
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_PROVEEDORES))) {
            proveedores = (List<Proveedor>) ois.readObject();
            System.out.println("Proveedores cargados: " + proveedores.size() + " registros");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar proveedores: " + e.getMessage());
            proveedores = new ArrayList<>();
        }
    }

    
    
    // CREATE - Agregar un nuevo proveedor
    public boolean agregarProveedor(Proveedor proveedor) {
        if (existeProveedor(proveedor.getDNI())) {
            return false;
        }
        proveedores.add(proveedor);
        guardarProveedores();
        return true;
    }

    // READ - Buscar proveedor por DNI
    public Proveedor buscarProveedor(String dni) {
        return proveedores.stream()
                .filter(p -> p.getDNI().equals(dni))
                .findFirst()
                .orElse(null);
    }

    // READ - Listar todos los proveedores
    public List<Proveedor> getProveedores() {
        return new ArrayList<>(proveedores);
    }

    // UPDATE - Modificar proveedor
    public boolean actualizarProveedor(Proveedor proveedorActualizado) {
        for (int i = 0; i < proveedores.size(); i++) {
            if (proveedores.get(i).getDNI().equals(proveedorActualizado.getDNI())) {
                proveedores.set(i, proveedorActualizado);
                guardarProveedores();
                return true;
            }
        }
        return false;
    }

    // DELETE - Eliminar proveedor
    public boolean eliminar(String dni) {
        Proveedor proveedor = buscarProveedor(dni);
        if (proveedor != null) {
            proveedores.remove(proveedor);
            guardarProveedores();
            return true;
        }
        return false;
    }

    // Método auxiliar para verificar existencia
    private boolean existeProveedor(String dni) {
        return buscarProveedor(dni) != null;
    }

    public int getCantidad() {
        return proveedores.size();
    }
}