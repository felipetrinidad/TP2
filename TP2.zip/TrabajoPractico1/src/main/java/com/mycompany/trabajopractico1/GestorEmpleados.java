/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

/**
 *
 * @author felip
 */
import java.util.ArrayList;
import java.util.List;
import java.io.*;

public class GestorEmpleados {
    private List<Empleado> empleados;
    private final String ARCHIVO_EMPLEADOS = "empleados.dat";

    public GestorEmpleados() {
        this.empleados = new ArrayList<>();
        cargarEmpleados();
    }
    
    
    // Metodos para guardar empleados en un archivo
    private void guardarEmpleados() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_EMPLEADOS))) {
            oos.writeObject(empleados);
            System.out.println("Empleados guardados en: " + ARCHIVO_EMPLEADOS);
        } catch (IOException e) {
            System.err.println("Error al guardar empleados: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void cargarEmpleados() {
        File archivo = new File(ARCHIVO_EMPLEADOS);
        if (!archivo.exists()) {
            System.out.println("Creando Archivo Empleados");
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_EMPLEADOS))) {
            empleados = (List<Empleado>)ois.readObject();
            System.out.println("Empleados cargados: " + empleados.size() + " registros");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar empleado: " + e.getMessage());
            empleados = new ArrayList<>();
        }
    }
    
    
    // Create: agregar un nuevo empleado
    public boolean agregarEmpleado(Empleado empleado) {
        if (existeEmpleado(empleado.getDNI())) {
            return false;
        }
        empleados.add(empleado);
        guardarEmpleados();
        return true;
    }

    // Read: obtener todos los empleados
    public List<Empleado> getEmpleados() {
        return new ArrayList<>(empleados);
    }

    // Read: buscar empleado por DNI
    public Empleado buscarEmpleado(String dni) {
        for (Empleado emp : empleados) {
            if (emp.getDNI().equals(dni)) {
            return emp;
            }
        }
        return null;
    }

    // Update: actualizar un empleado existente
    public boolean actualizarEmpleado(Empleado empleadoActualizado) {
        for (int i = 0; i < empleados.size(); i++) {
            if (empleados.get(i).getDNI().equals(empleadoActualizado.getDNI())) {
                empleados.set(i, empleadoActualizado);
                guardarEmpleados();
                return true;
            }
        }
        return false;
    }

    // Delete: eliminar un empleado por DNI
    public boolean eliminarEmpleado(String dni) {
        Empleado empleado = buscarEmpleado(dni);
        if (empleado != null) {
            empleados.remove(empleado);
            guardarEmpleados();
            return true;
        }
        return false;
    }
    
    
    // Método para verificar existencia
    public boolean existeEmpleado(String dni) {
        return buscarEmpleado(dni) != null;
    }
}
