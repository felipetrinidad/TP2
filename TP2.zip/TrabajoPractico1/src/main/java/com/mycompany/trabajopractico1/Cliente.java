/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;



/**
 *
 * @author felip
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Cliente extends Persona implements Serializable{
    // Atributos
    private double lim_cred;
    private List<Factura> historialCompra = new ArrayList<>();
    private Categoria categoria;
    private String mail;
    private static final long serialVersionUID = 1L; 
    
    public enum Categoria {
        REGULAR,
        PREMIUM,
        CORPORATIVO}
    
    
    //Constructor
    public Cliente(String nom, String dom, String dni, String tel,  double lim, Categoria categoria, String mail) {
        super(nom, dom, dni, tel);
        setLimCredito(lim);
        setCategoria(categoria);
        setEmail(mail);
    }
    
    
    //Metodos
    public void agregarAlHistorial(Factura factura) {
        historialCompra.add(factura);
    }
    
    //Setters con validaciones
    public void setLimCredito(double lim_cred) {
        if (lim_cred <= 0) {
            throw new IllegalArgumentException("El límite de crédito debe ser mayor a 0");
        }
        if (lim_cred > 1000000) {
            throw new IllegalArgumentException("El límite de crédito no puede exceder $1,000,000");
        }
        this.lim_cred = lim_cred;
    }
    
    
    public void setCategoria(Categoria categoria) {
        if (categoria == null) {
            throw new IllegalArgumentException("La categoría es obligatoria");
        }
        this.categoria = categoria;
    }
    
    
    public void setEmail(String mail) {
        if (mail != null && !mail.trim().isEmpty()) {
            if (!mail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                throw new IllegalArgumentException(
                    "Formato de email incorrecto. Ejemplo: usuario@dominio.com"
                );
            }
        }
        this.mail = mail;
    }
    
    
    //Getters
    public double getLimCredito(){return lim_cred;}
    public Categoria getCategoria() { return categoria; }
    public String getEmail() {return mail;}
  
    
    //Historial del Cliente
    public void getHistorial(){
        System.out.println("HISTORIAL DE COMPRAS  -  CLIENTE: " + getNombre());
        System.out.println("");
        if (historialCompra.isEmpty()) {
            System.out.println("El cliente no tiene compras registradas.");
        } else {
            for (int i = 0; i < historialCompra.size(); i++) {
                System.out.println("COMPRA #" + (i + 1) + ":");
                historialCompra.get(i).mostrarDetalle();
                System.out.println("----------------------------------------");
            }
        }
    }
    
    
    @Override
    public String toString() {
        return super.toString() + ", Categoria: " + getCategoria() + ",\nLimite Credito: $" +
                                getLimCredito() + ", Domicilio: " + getDomicilio();
    }
}
