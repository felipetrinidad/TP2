/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

/**
 *
 * @author felip
 */
public class NotificacionSMS implements NotificacionEnviar{

    @Override
    public void enviarNot(String destinatario, String mensaje) {
        // Simulación de envío de SMS
        System.out.println("=== ENVIANDO SMS ===");
        System.out.println("Numero: " + destinatario);
        System.out.println("Mensaje: " + mensaje);
        System.out.println("SMS enviado exitosamente!");
        System.out.println("====================");
        
    }
}
