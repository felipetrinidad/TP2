/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabajopractico1;
import com.mycompany.interfaz.Gui;

/**
 *
 * @author felip
 */
public class TrabajoPractico1 {
    private Gui gui;
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable(){public void run() {new Gui().setVisible(true);}});
        }
    
}
    

