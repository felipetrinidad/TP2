/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajopractico1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author felip
 */
public class Carrito {
    private List<ProductoServicio> items;
    private EstrategiaDescuento estrategia;
    private final double IVA = 0.21;

    public Carrito() {
        this.items = new ArrayList<>();
    }
    
    //setter y getter
    public void setEstrategia(EstrategiaDescuento estrategia) {
        this.estrategia = estrategia;
    }
    public EstrategiaDescuento getEstrategia(){return estrategia;}

    
    // Metodos: Create, Read y Delete
    public void agregarProducto(ProductoServicio producto) {
        items.add(producto);
    }
    
    public List<ProductoServicio> getItems() {
            return items;
        }
    
    public void eliminarProducto(ProductoServicio producto) {
        items.remove(producto);
    }
    
    
    // Subtotal sin IVA
    public double calcularSubtotal() {
        double subtotal = 0;
        if(getEstrategia() != null){
            subtotal = estrategia.aplicar(items);
            return subtotal;
        }
        for (ProductoServicio p : items) {
            subtotal += p.getPrecio();
        }
        return subtotal;
    }
    
    
    // Calcula el IVA (21%)
    public double calcularIVA() {
        return calcularSubtotal() * IVA;
    }

    // Total  
    public double calcularTotal() {
        double total = calcularSubtotal() + calcularIVA();
        return total;
    }
}
